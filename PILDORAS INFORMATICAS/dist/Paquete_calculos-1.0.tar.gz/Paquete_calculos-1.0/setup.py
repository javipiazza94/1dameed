from setuptools import setup

setup(
    name="Paquete_calculos",
    version="1.0",
    description="Paquete distribuible de operaciones matematicas basicas con dos argumentos",
    author="Javi P.Piazza",
    packages=["Paquetes"]
)